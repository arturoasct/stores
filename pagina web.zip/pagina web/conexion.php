<?php  
 	function consultar($query )
	{   
	   try {
			$gbd = new PDO('mysql:host=localhost; dbname=compras', "root", "");
			if($gbd){
			  $query = $gbd->prepare($query);
			  $query->execute();
			  $result = $query->fetchAll();
			  return $result;
			  }
			}   
      catch (PDOException $e) {
			print "¡Error!: " . $e->getMessage() . "<br/>";
			die();
			}
	}
	
	function guardar($query)
{
try {

$gbd= new PDO ('mysql:host=localhost; dbname=compras', "root", "");
if ($gbd){
 $query=$gbd->prepare($query);
 $query->execute();
 
 $errores=$query->errorInfo();
 $cuenta=$query->rowCount();
 if ($cuenta!=0)
 return "Los Datos se han guardado";
 else 
 return $errores [2];
 }
 
 }
 catch (PDOException $e){
 print " Error:" .$e->getMessage() . "<br/>";
 return $e->getMessage();
 
 }
 


 
 }

?>