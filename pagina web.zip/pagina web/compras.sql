-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 01-12-2015 a las 02:16:09
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `compras`
--
CREATE DATABASE IF NOT EXISTS `compras` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `compras`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE IF NOT EXISTS `compra` (
  `nombre` char(40) NOT NULL,
  `direccion` varchar(40) NOT NULL,
  `pais` char(30) NOT NULL,
  `telefono` int(10) NOT NULL,
  `articulo` varchar(30) NOT NULL,
  `secreto` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `compra`
--

INSERT INTO `compra` (`nombre`, `direccion`, `pais`, `telefono`, `articulo`, `secreto`) VALUES
('arturo', 'barrio mejia', 'honduras', 7890788, 'samsung galaxy S3', 2222),
('luis', 'barrio solares nuevos', 'honduras', 24408967, 'smart tv ', 23456);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
