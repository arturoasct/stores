

<?php
  function checkSet(){
  return isset($_POST['nombre']);
    return isset($_POST['direccion']);
    return isset($_POST['pais']);
    return isset($_POST['telefono']);
    return isset($_POST['secreto']);
	return isset($_POST['articulo']);
	
} 
?>




<?php
function sanityCheck($string, $type, $length){


  $type = 'is_'.$type;

  if(!$type($string))
    {
    return FALSE;
    }
  elseif(empty($string))
    {
    return FALSE;
    }
  elseif(strlen($string) > $length)
    {
    return FALSE;
    }
  else
    {
    return TRUE;
    }
}
?>

<?php
 
  function checkNumber($num, $length){
  if($num > 0 && strlen($num) == $length)
    {
    return TRUE;
    }
}
?>





<?php
  if(checkSet() != FALSE)
    {
    if(empty($_POST['nombre'])==FALSE && sanityCheck($_POST['nombre'], 'string', 15) != FALSE)
        {
        $nombre_usuario = $_POST['nombre'];
        }
    else
        {
        echo 'Ingrese un Nombre';
		 echo '----debe ingresar un maximo de 15 caracteres';
        exit();
        }

if(empty($_POST['direccion'])==FALSE && sanityCheck($_POST['direccion'], 'string', 15) != FALSE)
        {
        $nombre_usuario1 = $_POST['nombre'];
        }
    else
        {
        echo 'Ingrese una direccion';
		 echo '----debe ingresar un maximo de 15 caracteres';
        exit();
        }
 
	

	if(empty($_POST['pais'])==FALSE && sanityCheck($_POST['pais'], 'string', 15) != FALSE)
        {
        $nombre_usuario2 = $_POST['pais'];
        }
    else
        {
        echo 'Ingrese un pais';
		 echo '----debe ingresar un maximo de 15 caracteres';
        exit();
        }
	
		
		if(empty($_POST['telefono'])==FALSE && sanityCheck($_POST['telefono'], 'string', 15) != FALSE)
        {
        $nombre_usuario3 = $_POST['telefono'];
        }
    else
        {
        echo 'Ingrese numero';
		 echo '----debe ingresar un maximo de 15 numeros';
        exit();
        }
		
		if(empty($_POST['articulo'])==FALSE && sanityCheck($_POST['articulo'], 'string', 15) != FALSE)
        {
        $nombre_usuario4 = $_POST['articulo'];
        }
    else
        {
        echo 'Ingrese un articulo';
		 echo '----debe ingresar un maximo de 15 caracteres';
        exit();
        }
		
		if(empty($_POST['secreto'])==FALSE && sanityCheck($_POST['secreto'], 'string', 15) != FALSE)
        {
        $nombre_usuario5 = $_POST['secreto'];
        }
    else
        {
        echo 'Ingrese un numero secreto del banco';
		 echo '----debe ingresar un codigo secreto';
        exit();
        }
	 }
	
  else
    {
    echo '<p>Please fill in the form above</p>';
    }
?>




<?php
    include "conexion.php";
	$nombre=$_POST['nombre'];
$direccion=$_POST['direccion'];
	$pais=$_POST['pais'];

	$telefono=$_POST['telefono'];
	$articulo=$_POST['articulo'];
	$secreto=$_POST['secreto'];

			
		

			

	
			
			
	 function registrarEmpleado($nombre,$direccion,$pais,$telefono,$articulo,$secreto){

$cantidad=2;
		  if(isset($nombre,$direccion,$pais,$telefono,$articulo,$secreto)){
				$registrar=false;
				for($i = 0; $i < $cantidad; $i++){
				$consulta="insert into compra values('$nombre','$direccion','$pais','$telefono','$articulo','$secreto')";
                echo $consulta;
				$registrar = guardar($consulta);
                if($registrar !== false){
                   return true;
                    }
                else{
                  return false;
                    } }
             }
         
     }
	$ejecutar=registrarEmpleado($nombre,$direccion,$pais,$telefono,$articulo,$secreto);
	if($ejecutar==1){
	     header('location:index.html');

	} 
?>